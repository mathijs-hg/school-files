Step 1:

Write code in src/main/java/Hackers.java

Step 2:

Run using

```
./mvnw exec:java
```

Alternative:

1. Open directory with pom.xml in Intellij
